package com.example.covid_19;
import com.example.covid_19.*;


public class RequestProcessor {

    public static void getData(MainActivity mainActivity, MainActivity.RequestTypes value, String countryCode){
        RequestTask requestTask = new RequestTask(mainActivity, value);

        if(value == MainActivity.RequestTypes.WORLD) {
            requestTask.execute("https://api.thevirustracker.com/free-api?global=stats");
        }
        else if(value == MainActivity.RequestTypes.COUNTRIES) {
            requestTask.execute("https://api.thevirustracker.com/free-api?countryTotals=ALL");
        }
        else if(value == MainActivity.RequestTypes.COUNTRY && countryCode != null && !countryCode.trim().equals("")) {
            System.out.println("https://api.thevirustracker.com/free-api?countryTotal="+countryCode.trim());
            requestTask.execute("https://api.thevirustracker.com/free-api?countryTotal="+countryCode.trim());
        }
    }

    public static String makeFirstLetterCaps(String value){
        String toRet = "";
        for(String k : value.split("_")){
            toRet += String.valueOf(k.charAt(0)).toUpperCase() + k.substring(1) +" ";
        }
        return toRet.trim();
    }


}
