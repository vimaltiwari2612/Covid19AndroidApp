package com.example.covid_19;
import android.animation.TimeAnimator;

import com.example.covid_19.*;

import java.lang.reflect.Array;
import java.sql.Time;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class RequestProcessor {

    public static void getData(MainActivity mainActivity, MainActivity.RequestTypes value, String countryCode){
        RequestTask requestTask = new RequestTask(mainActivity, value);

        if(value == MainActivity.RequestTypes.WORLD) {
            requestTask.execute("https://api.thevirustracker.com/free-api?global=stats");
        }
        else if(value == MainActivity.RequestTypes.COUNTRIES) {
            requestTask.execute("https://api.thevirustracker.com/free-api?countryTotals=ALL");
        }
        else if(value == MainActivity.RequestTypes.COUNTRYTIMELINE){
            requestTask.execute("https://api.thevirustracker.com/free-api?countryTimeline="+countryCode);
        }
        else if((value == MainActivity.RequestTypes.INDIA || value == MainActivity.RequestTypes.COUNTRY) && countryCode != null && !countryCode.trim().equals("")) {
            requestTask.execute("https://api.thevirustracker.com/free-api?countryTotal="+countryCode.trim());
        }
    }

    public static String makeFirstLetterCaps(String value){
        String toRet = "";
        for(String k : value.split("_")){
            toRet += String.valueOf(k.charAt(0)).toUpperCase() + k.substring(1) +" ";
        }
        return toRet.trim();
    }

    public static Date formatDate(String value){
        Date toRet = null;
        try{
            toRet = new SimpleDateFormat("MM/dd/yyyy").parse(value);
        }
        catch (Exception e){
          toRet = null;
          Log.LogError("formatDate","RequestProcessor",e.getMessage());
        }
        return toRet;
    }

    public static Map<Integer,Integer> getMonthlyTimelines(List<Timeline> timelines){
        List<Timeline> montlyTimeLines = new ArrayList<Timeline>();
        Map<Integer,Integer> montlyTimeLinesMap = new HashMap<Integer,Integer>();
        for(Timeline timeline : timelines){
            Date date = timeline.getDate();
            int month = date.getMonth();
            if(!montlyTimeLinesMap.containsKey(month)){
                montlyTimeLinesMap.put(month,0);
            }
            int cases = montlyTimeLinesMap.get(month);
            cases = timeline.getTotalCases();
            montlyTimeLinesMap.put(month,cases);
        }
        return montlyTimeLinesMap;
    }
}
