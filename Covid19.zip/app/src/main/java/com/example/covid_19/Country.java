package com.example.covid_19;

import android.os.Parcelable;

import java.io.Serializable;
import java.net.URL;
import java.util.List;
import java.util.Objects;

public class Country implements Comparable, Serializable {

    private int countryCount;
    private String countryName;
    private String countryCode;
    private String url;
    private int totalCase;
    List<Data> casesData;
    List<LatestData> latestCasesData;
    List<Timeline> timelines;


    public Country(int countryCount, String countryName, String countryCode, String url, List<Data> casesData,List<LatestData> latestCasesData,int totalCase) {
        this.countryCount = countryCount;
        this.countryName = countryName;
        this.countryCode = countryCode;
        this.url = url;
        this.casesData = casesData;
        this.totalCase = totalCase;
        this.latestCasesData = latestCasesData;
    }

    public List<Timeline> getTimelines() {
        return timelines;
    }

    public void setTimelines(List<Timeline> timelines) {
        this.timelines = timelines;
    }

    public List<LatestData> getLatestCasesData() {
        return latestCasesData;
    }

    public void setLatestCasesData(List<LatestData> latestCasesData) {
        this.latestCasesData = latestCasesData;
    }

    public int getTotalCase() {
        return totalCase;
    }

    public void setTotalCase(int totalCase) {
        this.totalCase = totalCase;
    }

    public int getCountryCount() {
        return countryCount;
    }

    public void setCountryCount(int countryCount) {
        this.countryCount = countryCount;
    }

    public String getCountryName() {
        return countryName;
    }

    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public List<Data> getCasesData() {
        return casesData;
    }

    public void setCasesData(List<Data> casesData) {
        this.casesData = casesData;
    }

    public int compareTo(Object o){
        Country c1 = (Country)o;
        return this.totalCase - c1.totalCase;
    }

    public boolean equals(Object o){
        Country c1 = (Country)o;
        return this.countryCount == c1.countryCount;
    }

    @Override
    public int hashCode() {
        return Objects.hash(countryCount, countryName, countryCode, url, totalCase, casesData);
    }
}
