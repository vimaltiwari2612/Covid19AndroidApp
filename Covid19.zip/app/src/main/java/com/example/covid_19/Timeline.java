package com.example.covid_19;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Objects;


public class Timeline implements Serializable, Comparable {

    private Date date;
    private int day;
    private List<Data> details;
    private int totalCases;
    private int totalDeaths;

    public Timeline(String date, int day,String totalCases,String totalDeaths, List<Data> details) {
        this.date = RequestProcessor.formatDate(date);
        this.day = day;
        this.details = details;
        this.totalCases = Integer.parseInt(totalCases);
        this.totalDeaths = Integer.parseInt(totalDeaths);
    }

    public int getTotalCases() {
        return totalCases;
    }

    public void setTotalCases(int totalCases) {
        this.totalCases = totalCases;
    }

    public int getTotalDeaths() {
        return totalDeaths;
    }

    public void setTotalDeaths(int totalDeaths) {
        this.totalDeaths = totalDeaths;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public int getDay() {
        return day;
    }

    public void setDay(int day) {
        this.day = day;
    }

    public List<Data> getDetails() {
        return details;
    }

    public void setDetails(List<Data> details) {
        this.details = details;
    }

    @Override
    public int compareTo(Object o) {
        Timeline timeline = (Timeline) o;
        return this.totalCases - timeline.totalCases;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Timeline timeline = (Timeline) o;
        return (totalCases == timeline.totalCases &&
                totalDeaths == timeline.totalDeaths);
    }

    @Override
    public int hashCode() {
        return Objects.hash(date, day, details, totalCases, totalDeaths);
    }
}
