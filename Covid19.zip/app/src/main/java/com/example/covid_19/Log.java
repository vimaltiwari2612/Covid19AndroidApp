package com.example.covid_19;

public class Log {

    public static void LogInfo(String message){
        System.out.println("Log Info : "+message);
    }

    public static void LogError(String methodName, String className, String message){
        System.out.println("Log Error : "+message+" | Class : "+className + " and in method : "+methodName);
    }
}
