package com.example.covid_19;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.BarGraphSeries;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import java.sql.Time;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;

public class CountryDetails extends AppCompatActivity {
    private Country country;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_country_details);
        init();
        createTimeline();
        buildCurrentStats();
    }

    private void buildCurrentStats(){
        TextView cases = (TextView) findViewById(R.id.newCases);
        TextView deaths = (TextView) findViewById(R.id.newDeaths);

        List<LatestData> latestData = this.country.getLatestCasesData();
        String casesString = latestData.get(0).getKey()+" = "+latestData.get(0).getValue();
        String deathString = latestData.get(1).getKey()+" = "+latestData.get(1).getValue();
        cases.setText(casesString);
        deaths.setText(deathString);
    }

    private void init(){
        this.country = (Country) this.getIntent().getSerializableExtra("CountryDetails");
        System.out.println(country.getCountryCode());
        setTitle(country.getCountryName() + "\'s Timelines");
    }

    private void createTimeline(){
        List<Timeline> timelines = this.country.getTimelines();
        Log.LogInfo("fetched timelines ");
        Collections.sort(timelines);
        Log.LogInfo("Sorted timelines");
        this.totalCasesTimeLine(timelines);
        Log.LogInfo("created Total cases timelines");
        this.totalDeathsTimeLine(timelines);
        Log.LogInfo("created Total deaths timelines");
    }

    private void totalCasesTimeLine(List<Timeline> timelines){
        GraphView graph = (GraphView) findViewById(R.id.graph);
        List<DataPoint> dp = new ArrayList<>();
        int maxX = -1;
        int lastVal = -1;
        for(Timeline timeline : timelines){

            if(lastVal == timeline.getTotalCases()){
                continue;
            }
            if(lastVal == -1){
                lastVal = timeline.getTotalCases();
            }
            DataPoint d = new DataPoint(timeline.getDay() , timeline.getTotalCases());
            dp.add(d);
            if(timeline.getDay() > maxX){
                maxX = timeline.getDay();
            }
        }
        this.drawTimeline(graph,dp.toArray(new DataPoint[dp.size()]),maxX);
    }

    private void totalDeathsTimeLine(List<Timeline> timelines){
        GraphView graph = (GraphView) findViewById(R.id.graph1);
        List<DataPoint> dp = new ArrayList<>();
        int maxX = -1;
        for(Timeline timeline : timelines){
            DataPoint d = new DataPoint(timeline.getDay() , timeline.getTotalDeaths());
            dp.add(d);
            if(timeline.getDay() > maxX){
                maxX = timeline.getDay();
            }
        }
        this.drawTimeline(graph,dp.toArray(new DataPoint[dp.size()]),maxX);
    }

    private void drawTimeline(GraphView graphView,DataPoint[] dataPoints , int maxX ){
        BarGraphSeries<DataPoint> series = new BarGraphSeries<DataPoint>(dataPoints);
        series.setAnimated(true);
        DataPoint dp = new DataPoint(maxX+200,0);
        series.appendData(dp,true,0,false);
        graphView.addSeries(series);
    }
}
