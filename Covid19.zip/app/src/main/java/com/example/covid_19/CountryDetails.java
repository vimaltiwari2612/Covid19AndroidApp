package com.example.covid_19;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import java.sql.Time;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

public class CountryDetails extends AppCompatActivity {
    private Country country;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_country_details);
        init();
        createTimeline();
    }

    private void init(){
        this.country = (Country) this.getIntent().getSerializableExtra("CountryDetails");
        System.out.println(country.getCountryCode());
    }

    private void createTimeline(){
        List<Timeline> timelines = this.country.getTimelines();
        Log.LogInfo("fetched timelines ");
        Collections.sort(timelines);
        Log.LogInfo("Sorted timelines");
        this.totalCasesTimeLine(timelines);
        Log.LogInfo("created Total cases timelines");
        this.totalDeathsTimeLine(timelines);
        Log.LogInfo("created Total deaths timelines");
    }

    private void totalCasesTimeLine(List<Timeline> timelines){
        GraphView graph = (GraphView) findViewById(R.id.graph);
        List<DataPoint> dp = new ArrayList<>();
        for(Timeline timeline : timelines){
            DataPoint d = new DataPoint(timeline.getDay() , timeline.getTotalCases());
            dp.add(d);
        }
        this.drawTimeline(graph,dp.toArray(new DataPoint[dp.size()]));
    }

    private void totalDeathsTimeLine(List<Timeline> timelines){
        GraphView graph = (GraphView) findViewById(R.id.graph1);
        List<DataPoint> dp = new ArrayList<>();
        for(Timeline timeline : timelines){
            DataPoint d = new DataPoint(timeline.getDay() , timeline.getTotalDeaths());
            dp.add(d);
        }
        this.drawTimeline(graph,dp.toArray(new DataPoint[dp.size()]));
    }

    private void drawTimeline(GraphView graphView,DataPoint[] dataPoints){
        LineGraphSeries<DataPoint> series = new LineGraphSeries<DataPoint>(dataPoints);
        graphView.addSeries(series);
    }
}
