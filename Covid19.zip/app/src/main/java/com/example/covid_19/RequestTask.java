package com.example.covid_19;
import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.Message;
import android.util.JsonReader;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;


class RequestTask extends AsyncTask<String, String, String>{
    private String resp;
    private ProgressDialog progressDialog;
    private MainActivity mainActivity;

    public RequestTask(MainActivity mainActivity){
        this.mainActivity = mainActivity;
    }

    public String getData(){
        return this.resp;
    }
    @Override
    protected String doInBackground(String... uri) {

        StringBuffer response = new StringBuffer();
// Create connection
        try {
            // Create URL
            URL githubEndpoint = new URL(uri[0]);
            HttpsURLConnection con =
                    (HttpsURLConnection) githubEndpoint.openConnection();
            con.setRequestMethod("GET");
            int responseCode = con.getResponseCode();
            System.out.println("GET Response Code :: " + responseCode);
            if (responseCode == HttpURLConnection.HTTP_OK) { // success
                BufferedReader in = new BufferedReader(new InputStreamReader(
                        con.getInputStream()));
                String inputLine;

                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                in.close();
                // print result
                System.out.println(response.toString());
                //pasrse JSON
                JSONObject jsonObj = new JSONObject(response.toString());
                // Getting JSON Array node
                JSONArray results = jsonObj.getJSONArray("results");

                this.mainActivity.dataList.add(new Data("total_cases",results.getJSONObject(0).getString("total_cases")));
                this.mainActivity.dataList.add(new Data("total_recovered",results.getJSONObject(0).getString("total_recovered")));
                this.mainActivity.dataList.add(new Data("total_unresolved",results.getJSONObject(0).getString("total_unresolved")));
                this.mainActivity.dataList.add(new Data("total_deaths",results.getJSONObject(0).getString("total_deaths")));
                this.mainActivity.dataList.add(new Data("total_new_cases_today",results.getJSONObject(0).getString("total_new_cases_today")));
                this.mainActivity.dataList.add(new Data("total_active_cases",results.getJSONObject(0).getString("total_active_cases")));
                this.mainActivity.dataList.add(new Data("total_serious_cases",results.getJSONObject(0).getString("total_serious_cases")));
                this.mainActivity.dataList.add(new Data("total_new_deaths_today",results.getJSONObject(0).getString("total_new_deaths_today")));
                this.mainActivity.dataList.add(new Data("total_affected_countries",results.getJSONObject(0).getString("total_affected_countries")));

            } else {
                System.out.println("GET request not worked");
            }
            con.disconnect();
                //JSON PARSING ENDS

        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("Do backgroudn resp : "+response);
        return response.toString();
    }

    @Override
    protected void onPostExecute(String result) {
        //Do anything with response.
        resp = result;
        System.out.println("Post execute" + resp);
        this.mainActivity.buildFrame();
        progressDialog.dismiss();

    }

    @Override
    protected void onPreExecute() {
        System.out.println("Pre execute");
        progressDialog = new ProgressDialog(this.mainActivity);
        progressDialog.setMax(100);
        progressDialog.setMessage("Getting data....");
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog.show();
    }

    @Override
    protected void onProgressUpdate(String... text) {
        System.out.println("connecting..." + text);
    }
}
