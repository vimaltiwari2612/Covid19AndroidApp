package com.example.covid_19;
import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.Message;
import android.util.JsonReader;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

import javax.net.ssl.HttpsURLConnection;


public class RequestTask extends AsyncTask<String, String, String> {
    private String resp;
    private MainActivity.RequestTypes vType;
    private ProgressDialog progressDialog;
    private MainActivity mainActivity;

    public RequestTask(MainActivity mainActivity) {
        this.mainActivity = mainActivity;
    }

    public RequestTask(MainActivity mainActivity, MainActivity.RequestTypes vType) {
        this.mainActivity = mainActivity;
        this.vType = vType;
    }

    public String getData() {
        return this.resp;
    }

    @Override
    protected String doInBackground(String... uri) {

        StringBuffer response = new StringBuffer();
// Create connection
        try {
            // Create URL
            URL githubEndpoint = new URL(uri[0]);
            HttpsURLConnection con =
                    (HttpsURLConnection) githubEndpoint.openConnection();
            con.setRequestMethod("GET");
            int responseCode = con.getResponseCode();
            //   System.out.println("GET Response Code :: " + responseCode);
            if (responseCode == HttpURLConnection.HTTP_OK) { // success
                BufferedReader in = new BufferedReader(new InputStreamReader(
                        con.getInputStream()));
                String inputLine;

                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                in.close();
                // print result
                //  System.out.println(response.toString());
                if (vType == MainActivity.RequestTypes.WORLD) {
                    populateWorldData(response.toString());
                } else if (vType == MainActivity.RequestTypes.COUNTRIES) {
                    populateCountriesData(response.toString());
                } else if (vType == MainActivity.RequestTypes.INDIA || vType == MainActivity.RequestTypes.COUNTRY) {
                    populateCountryData(response.toString());
                }
            } else {
                  System.out.println("GET request not worked");
            }
            con.disconnect();
            //JSON PARSING ENDS

        } catch (Exception e) {
            e.printStackTrace();
        }
        //  System.out.println("Do backgroudn resp : "+response);
        return response.toString();
    }

    @Override
    protected void onPostExecute(String result) {
        //Do anything with response.
        resp = result;

        if (vType == MainActivity.RequestTypes.WORLD) {
            RequestProcessor.getData(this.mainActivity, MainActivity.RequestTypes.COUNTRIES, null);
        }
        if (vType == MainActivity.RequestTypes.COUNTRIES) {
            System.out.println("calling India data");
            RequestProcessor.getData(this.mainActivity, MainActivity.RequestTypes.INDIA, "IN");
        }
        if (vType == MainActivity.RequestTypes.INDIA) {
            this.mainActivity.buildFrame();
        }
        if (vType == MainActivity.RequestTypes.COUNTRY) {
            System.out.println("Requried data " + this.mainActivity.searchedCountry);
            this.mainActivity.countryData();
        }
        progressDialog.dismiss();
    }

    @Override
    protected void onPreExecute() {
        //  System.out.println("Pre execute");
        progressDialog = new ProgressDialog(this.mainActivity);
        progressDialog.setMax(100);
        progressDialog.setMessage("Getting data....");
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog.show();
    }

    @Override
    protected void onProgressUpdate(String... text) {
        System.out.println("connecting..." + text);
    }


    private void populateWorldData(String response) {
        //pasrse JSON
        JSONObject jsonObj = null;
        try {
            jsonObj = new JSONObject(response);

            // Getting JSON Array node
            JSONArray results = jsonObj.getJSONArray("results");
            ArrayList<Data> dataList = new ArrayList<Data>();
            dataList.add(new Data("total_cases", results.getJSONObject(0).getString("total_cases")));
            dataList.add(new Data("total_affected_countries", results.getJSONObject(0).getString("total_affected_countries")));
            dataList.add(new Data("total_active_cases", results.getJSONObject(0).getString("total_active_cases")));
            dataList.add(new Data("total_recovered", results.getJSONObject(0).getString("total_recovered")));
            dataList.add(new Data("total_unresolved", results.getJSONObject(0).getString("total_unresolved")));
            dataList.add(new Data("total_deaths", results.getJSONObject(0).getString("total_deaths")));
            dataList.add(new Data("total_serious_cases", results.getJSONObject(0).getString("total_serious_cases")));

            ArrayList<LatestData> latestDataList = new ArrayList<LatestData>();
            latestDataList.add(new LatestData("total_new_cases_today", results.getJSONObject(0).getString("total_new_cases_today")));
            latestDataList.add(new LatestData("total_new_deaths_today", results.getJSONObject(0).getString("total_new_deaths_today")));

            this.mainActivity.WORLDDATA = new Country(0,"WORLD",null,null,dataList,latestDataList,0);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void populateCountriesData(String response) {
        //pasrse JSON
        JSONObject jsonObj = null;
        try {
            jsonObj = new JSONObject(response);

            // Getting JSON Array node
            JSONArray obj = jsonObj.getJSONArray("countryitems");
            JSONObject vData = (JSONObject) obj.get(0);
            int i = 1;
            try {

                for (i = 1; ; i++) {
                    String temp = (String) vData.getString(String.valueOf(i));
                    jsonObj = new JSONObject(temp);
                    ArrayList<Data> dataList = new ArrayList<Data>();
                    dataList.add(new Data("total_cases", jsonObj.getString("total_cases")));
                    dataList.add(new Data("total_active_cases", jsonObj.getString("total_active_cases")));
                    dataList.add(new Data("total_recovered", jsonObj.getString("total_recovered")));
                    dataList.add(new Data("total_unresolved", jsonObj.getString("total_unresolved")));
                    dataList.add(new Data("total_serious_cases", jsonObj.getString("total_serious_cases")));
                    dataList.add(new Data("total_deaths", jsonObj.getString("total_deaths")));

                    //latest data
                    ArrayList<LatestData> latestDataList = new ArrayList<LatestData>();
                    latestDataList.add(new LatestData("total_new_cases_today", jsonObj.getString("total_new_cases_today")));
                    latestDataList.add(new LatestData("total_new_deaths_today", jsonObj.getString("total_new_deaths_today")));

                    Country c = new Country(Integer.parseInt(jsonObj.getString("ourid")), jsonObj.getString("title"), jsonObj.getString("code"), jsonObj.getString("source"), dataList,latestDataList, Integer.parseInt(jsonObj.getString("total_cases")));
                    this.mainActivity.countryNamesVsCountryCode.put(c.getCountryName().toLowerCase(),c.getCountryCode());
                    this.mainActivity.countriesDataList.add(c);

                }
            } catch (Exception e) {
                i--;
                System.out.println("total countries found : " + i);
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void populateCountryData(String response) {
        //pasrse JSON
        JSONObject jsonObj = null;
        try {
            jsonObj = new JSONObject(response);
            // Getting JSON Array node
            JSONArray obj = jsonObj.getJSONArray("countrydata");
            String info = obj.getString(0);
            jsonObj = new JSONObject(info);
            info = jsonObj.getString("info");
            ArrayList<Data> dataList = new ArrayList<Data>();
            dataList.add(new Data("total_cases", jsonObj.getString("total_cases")));
            dataList.add(new Data("total_active_cases", jsonObj.getString("total_active_cases")));
            dataList.add(new Data("total_recovered", jsonObj.getString("total_recovered")));
            dataList.add(new Data("total_unresolved", jsonObj.getString("total_unresolved")));
            dataList.add(new Data("total_serious_cases", jsonObj.getString("total_serious_cases")));
            dataList.add(new Data("total_deaths", jsonObj.getString("total_deaths")));
            //add to latest data
            ArrayList<LatestData> latestDataList = new ArrayList<LatestData>();
            latestDataList.add(new LatestData("total_new_cases_today", jsonObj.getString("total_new_cases_today")));
            latestDataList.add(new LatestData("total_new_deaths_today", jsonObj.getString("total_new_deaths_today")));
            jsonObj = new JSONObject(info);
            if(vType == MainActivity.RequestTypes.COUNTRY){
                this.mainActivity.searchedCountry = new Country(Integer.parseInt(jsonObj.getString("ourid")), jsonObj.getString("title"), jsonObj.getString("code"), jsonObj.getString("source"), dataList, latestDataList, 0);
            }
            else {
                this.mainActivity.searchedCountry = new Country(Integer.parseInt(jsonObj.getString("ourid")), jsonObj.getString("title"), jsonObj.getString("code"), jsonObj.getString("source"), dataList, latestDataList, 0);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}
