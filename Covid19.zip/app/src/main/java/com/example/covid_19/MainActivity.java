package com.example.covid_19;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;

import org.json.JSONArray;
import org.json.JSONObject;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.example.covid_19.*;
public class MainActivity extends AppCompatActivity {

    public ArrayList<Country> countriesDataList;
    public Country INDIA;
    public Country WORLDDATA;

    public enum RequestTypes {WORLD, COUNTRIES , COUNTRY , WORLDTIMELINE, COUNTRYTIMELINE, MOST,LEAST}
    PieChart pieChart ;
    ArrayList<Entry> entries ;
    ArrayList<String> PieEntryLabels ;
    PieDataSet pieDataSet ;
    PieData pieData ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        countriesDataList = new ArrayList<Country>();
        setContentView(R.layout.activity_main);
        RequestProcessor.getData(this,RequestTypes.WORLD,null);
    }

    public void buildFrame(){
        Collections.sort(countriesDataList);
        buildStats();
        buildCharts();
    }

    private void buildCharts(){
        int count = 10;
        affectedCountries(count, RequestTypes.MOST);
        affectedCountries(count, RequestTypes.LEAST);
    }

    public void affectedCountries(int count, RequestTypes value){
        //System.out.println("Building chart for "+ value);
        if(value == RequestTypes.MOST) {
            pieChart = (PieChart) findViewById(R.id.chart1);
        }
        else if(value == RequestTypes.LEAST){
           pieChart = (PieChart) findViewById(R.id.chart2);
        }
        entries = new ArrayList<>();

        PieEntryLabels = new ArrayList<String>();

        int start = 0;
        int end = count;

        if(value == RequestTypes.MOST){
            start = countriesDataList.size() - 1;
            end = countriesDataList.size() - (count + 1) ;
        }
        for(int i=start,temp = 0  ;;){
            Country c = countriesDataList.get(i);
            //System.out.println("============= "+value.name());
            if(value == RequestTypes.MOST){
                if(countriesDataList.get(i).getTotalCase() > 0) {
                    System.out.println(c.getCountryName() + " count "+c.getTotalCase());
                    PieEntryLabels.add(c.getCountryName() );
                    entries.add(new BarEntry((float)c.getTotalCase(), i));
                }
                if(i > end) i--;
                else break;
            }

            else if(value == RequestTypes.LEAST){
                if(countriesDataList.get(i).getTotalCase() > 0) {
                //    System.out.println(c.getCountryName() + " count "+c.getTotalCase());
                    PieEntryLabels.add(c.getCountryName());
                    entries.add(new BarEntry((float)c.getTotalCase(), i));
                    temp++;
                }
                if(i <= end) i++;
                else {
                   // System.out.println("temp "+temp + "| count : "+count);
                    if(temp < count){
                        end +=count - temp;
                    }
                    else{
                        break;
                    }
                }
            }

        }
        //System.out.println("entries "+ entries);
        pieDataSet = new PieDataSet(entries, "");

        pieData = new PieData(PieEntryLabels, pieDataSet);

        pieDataSet.setColors(CustomColorTemplate.COLORFUL_COLORS);

        pieChart.setData(pieData);

        pieChart.animateY(3000);
    }

    private void buildStats(){
        worldData();
        indiaData();
    }

    private void indiaData(){
        TextView t3 = findViewById(R.id.textView31);
        TextView t4 = findViewById(R.id.textView41);
        TextView t5 = findViewById(R.id.textView51);
        TextView t6 = findViewById(R.id.textView61);
        TextView t7 = findViewById(R.id.textView71);
        TextView t8 = findViewById(R.id.textView81);


        List<Data> dataList = INDIA.getCasesData();

        t3.setText(dataList.get(0).getKey() +"\n\n"+dataList.get(0).getValue());
        t4.setText(dataList.get(1).getKey()+"\n\n"+dataList.get(1).getValue());
        t5.setText(dataList.get(2).getKey()+"\n\n"+dataList.get(2).getValue());
        t6.setText(dataList.get(3).getKey()+"\n\n"+dataList.get(3).getValue());
        t7.setText(dataList.get(4).getKey()+"\n\n"+dataList.get(4).getValue());
        t8.setText(dataList.get(5).getKey()+"\n\n"+dataList.get(5).getValue());

    }
    private void worldData(){
        TextView t3 = findViewById(R.id.textView3);
        TextView t4 = findViewById(R.id.textView4);
        TextView t5 = findViewById(R.id.textView5);
        TextView t6 = findViewById(R.id.textView6);
        TextView t7 = findViewById(R.id.textView7);
        TextView t8 = findViewById(R.id.textView8);
        TextView t9 = findViewById(R.id.textView9);


        ArrayList<Data> dataList = (ArrayList<Data>)WORLDDATA.getCasesData();
        t3.setText(dataList.get(0).getKey() +"\n\n"+dataList.get(0).getValue());
        t4.setText(dataList.get(1).getKey()+"\n\n"+dataList.get(1).getValue());
        t5.setText(dataList.get(2).getKey()+"\n\n"+dataList.get(2).getValue());
        t6.setText(dataList.get(3).getKey()+"\n\n"+dataList.get(3).getValue());
        t7.setText(dataList.get(4).getKey()+"\n\n"+dataList.get(4).getValue());
        t8.setText(dataList.get(5).getKey()+"\n\n"+dataList.get(5).getValue());
        t9.setText(dataList.get(6).getKey()+"\n\n"+dataList.get(6).getValue());

    }


}
