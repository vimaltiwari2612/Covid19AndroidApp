package com.example.covid_19;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    public ListView worldList;
    public ArrayList<Data> dataList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        dataList = new ArrayList<Data>();
        setContentView(R.layout.activity_main);
        RequestTask requestTask = new RequestTask(this);
        requestTask.execute("https://api.thevirustracker.com/free-api?global=stats");
    }

    public void buildFrame(){

        System.out.println("dataList"+dataList);
        CustomArrayAdapter caa = new CustomArrayAdapter(this,dataList);
        worldList = (ListView) findViewById(R.id.worldList);
        worldList.setAdapter(caa);
    }


     class CustomArrayAdapter extends ArrayAdapter<Data> {
        public CustomArrayAdapter(Context context, ArrayList<Data> data) {

            super(context, 0, data);
            System.out.println("Inside custo adapter"+data);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            // Get the data item for this position
            System.out.println("Inside View (position) "+position);
            System.out.println("Inside View getItem(position) "+getItem(position));

            Data data = getItem(position);
            System.out.println("Inside View Data "+data);
            System.out.println("Inside View  key"+data.getKey());
            System.out.println("Inside View value "+data.getValue());
            // Check if an existing view is being reused, otherwise inflate the view
            if (convertView == null) {
                convertView = LayoutInflater.from(getContext()).inflate(R.layout.worldlist_layout, parent, false);
            }
            System.out.println("Inside View  convertView "+convertView);
            // Lookup view for data population
            TextView tvItem = (TextView) convertView.findViewById(R.id.item);
            TextView tvValue = (TextView) convertView.findViewById(R.id.value);
            // Populate the data into the template view using the data object
            System.out.println("Inside View  tvItem "+tvItem);
            tvItem.setText(data.getKey());
            tvValue.setText(data.getValue());
            // Return the completed view to render on screen
            return convertView;
        }
    }
}
