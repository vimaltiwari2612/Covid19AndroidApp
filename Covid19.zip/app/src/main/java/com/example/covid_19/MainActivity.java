package com.example.covid_19;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.github.mikephil.charting.data.Entry;

public class MainActivity extends AppCompatActivity {

    public ArrayList<Country> countriesDataList;
    public Map<String,String> countryNamesVsCountryCode;
    public Country WORLDDATA,searchedCountry;
    public enum RequestTypes {WORLD, COUNTRIES , INDIA,COUNTRY , WORLDTIMELINE, COUNTRYTIMELINE, MOST,LEAST}
    //local vars
    PieChart pieChart ;
    EditText searchedText;
    Button search, seeMore;
    ArrayList<Entry> entries ;
    ArrayList<String> PieEntryLabels ;
    PieDataSet pieDataSet ;
    PieData pieData ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        init();
        processRequest();
    }

    private void init(){
        countriesDataList = new ArrayList<Country>();
        setContentView(R.layout.activity_main);
        searchedText = (EditText) findViewById(R.id.searchText);
        search = (Button) findViewById(R.id.button);
        seeMore = (Button) findViewById(R.id.seeMore);
        countryNamesVsCountryCode = new HashMap<>();
        addListeners();
    }

    private void addListeners(){
        search.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                String q = MainActivity.this.searchedText.getText().toString();
                if(!MainActivity.this.countryNamesVsCountryCode.keySet().contains(q.trim().toLowerCase())){
                    Toast.makeText(getApplicationContext(),"Stats Not Available for "+MainActivity.this.searchedText.getText(),Toast.LENGTH_LONG);
                    System.out.println(q + " Not Found" );
                }
                else{
                    Toast.makeText(getApplicationContext(),"Searching stats of "+MainActivity.this.searchedText.getText(),Toast.LENGTH_LONG);
                    System.out.println(q + " Found" );
                    RequestProcessor.getData(MainActivity.this,RequestTypes.COUNTRY,MainActivity.this.countryNamesVsCountryCode.get(q.toLowerCase()));
                }
            }
        });

        seeMore.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
               System.out.println("clicked See more for "+searchedCountry.getCountryName());
               RequestProcessor.getData(MainActivity.this,RequestTypes.COUNTRYTIMELINE,MainActivity.this.searchedCountry.getCountryCode());
            }
        });
    }

    private void processRequest(){
        RequestProcessor.getData(this,RequestTypes.WORLD,null);
    }

    public void buildFrame(){
        Collections.sort(countriesDataList);
        worldData();
        countryData();
        buildCharts();
    }

    public void showCountryDetails(){
        Intent intent = new Intent(MainActivity.this, CountryDetails.class);
        intent.putExtra("CountryDetails",this.searchedCountry);
        startActivity(intent);
    }

    private void buildCharts(){
        int count = 10;
        affectedCountries(count, RequestTypes.MOST);
        affectedCountries(count, RequestTypes.LEAST);
    }

    public void affectedCountries(int count, RequestTypes value){
        //System.out.println("Building chart for "+ value);
        if(value == RequestTypes.MOST) {
            pieChart = (PieChart) findViewById(R.id.chart1);
        }
        else if(value == RequestTypes.LEAST){
           pieChart = (PieChart) findViewById(R.id.chart2);
        }
        entries = new ArrayList<>();

        PieEntryLabels = new ArrayList<String>();

        int start = 0;
        int end = count;

        if(value == RequestTypes.MOST){
            start = countriesDataList.size() - 1;
            end = countriesDataList.size() - (count + 1) ;
        }
        for(int i=start,temp = 0  ;;){
            Country c = countriesDataList.get(i);
            //System.out.println("============= "+value.name());
            if(value == RequestTypes.MOST){
                if(countriesDataList.get(i).getTotalCase() > 0) {
                   // System.out.println(c.getCountryName() + " count "+c.getTotalCase());
                    PieEntryLabels.add(c.getCountryName() );
                    entries.add(new BarEntry((float)c.getTotalCase(), i));
                }
                if(i > end) i--;
                else break;
            }

            else if(value == RequestTypes.LEAST){
                if(countriesDataList.get(i).getTotalCase() > 0) {
                //    System.out.println(c.getCountryName() + " count "+c.getTotalCase());
                    PieEntryLabels.add(c.getCountryName());
                    entries.add(new BarEntry((float)c.getTotalCase(), i));
                    temp++;
                }
                if(i <= end) i++;
                else {
                   // System.out.println("temp "+temp + "| count : "+count);
                    if(temp < count){
                        end +=count - temp;
                    }
                    else{
                        break;
                    }
                }
            }

        }
        //System.out.println("entries "+ entries);
        pieDataSet = new PieDataSet(entries, "");

        pieData = new PieData(PieEntryLabels, pieDataSet);

        pieDataSet.setColors(CustomColorTemplate.COLORFUL_COLORS);

        pieChart.setData(pieData);

        pieChart.animateY(3000);
    }

    public void countryData(){
        TextView countryStats = (TextView)findViewById(R.id.countryStats);

        TextView t3 = findViewById(R.id.textView31);
        TextView t4 = findViewById(R.id.textView41);
        TextView t5 = findViewById(R.id.textView51);
        TextView t6 = findViewById(R.id.textView61);
        TextView t7 = findViewById(R.id.textView71);
        TextView t8 = findViewById(R.id.textView81);

        List<Data> dataList = searchedCountry.getCasesData();
        countryStats.setText(searchedCountry.getCountryName()+" Statistics");
        t3.setText(dataList.get(0).getKey() +"\n\n"+dataList.get(0).getValue());
        t4.setText(dataList.get(1).getKey()+"\n\n"+dataList.get(1).getValue());
        t5.setText(dataList.get(2).getKey()+"\n\n"+dataList.get(2).getValue());
        t6.setText(dataList.get(3).getKey()+"\n\n"+dataList.get(3).getValue());
        t7.setText(dataList.get(4).getKey()+"\n\n"+dataList.get(4).getValue());
        t8.setText(dataList.get(5).getKey()+"\n\n"+dataList.get(5).getValue());

    }
    private void worldData(){
        TextView t3 = findViewById(R.id.textView3);
        TextView t4 = findViewById(R.id.textView4);
        TextView t5 = findViewById(R.id.textView5);
        TextView t6 = findViewById(R.id.textView6);
        TextView t7 = findViewById(R.id.textView7);
        TextView t8 = findViewById(R.id.textView8);
        TextView t9 = findViewById(R.id.textView9);

        Log.LogInfo("WORLDDATA - "+WORLDDATA);
        Log.LogInfo("Latest cases - "+WORLDDATA.getLatestCasesData());
        Log.LogInfo("casesData - "+WORLDDATA.getCasesData());
        Log.LogInfo("CountryName - "+WORLDDATA.getCountryName());

        ArrayList<Data> dataList = (ArrayList<Data>)WORLDDATA.getCasesData();
        t3.setText(dataList.get(0).getKey() +"\n\n"+dataList.get(0).getValue());
        t4.setText(dataList.get(1).getKey()+"\n\n"+dataList.get(1).getValue());
        t5.setText(dataList.get(2).getKey()+"\n\n"+dataList.get(2).getValue());
        t6.setText(dataList.get(3).getKey()+"\n\n"+dataList.get(3).getValue());
        t7.setText(dataList.get(4).getKey()+"\n\n"+dataList.get(4).getValue());
        t8.setText(dataList.get(5).getKey()+"\n\n"+dataList.get(5).getValue());
        t9.setText(dataList.get(6).getKey()+"\n\n"+dataList.get(6).getValue());

    }


}
